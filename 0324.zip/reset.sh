#!/usr/bin/bash 

echo  "deregister "
./triggerDeregister.sh


echo  "deactivate carriers"
./triggerDeactivate.sh


bash stop.sh

sleep 1

bash nohup-start.sh

sleep 1
