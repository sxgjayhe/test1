#!/bin/bash
cd $(dirname $0)
unset https_proxy http_proxy
nohup java -jar -DappName=domain-proxy -Dlogging.config=./log4j2.xml domain-proxy-1.0-SNAPSHOT.jar  &>/dev/null &
