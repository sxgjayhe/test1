#!/bin/bash


URL="http://127.0.0.1:8000/api/DP/registrationRequest"

response=$(curl -s --noproxy "*" -X POST "$URL" \
     -H "Content-Type: application/json;charset=UTF-8" \
     -H "Accept: application/json" \
     -H "device-url-info: http://127.0.0.1:5000" \
     -d '{
"inquiredSpectrum": [
    {
	          "highFrequency": 3570000000,
		        "lowFrequency": 3550000000
			    }
		      ],
"measReport": {
    "rcvdPowerMeasReports": [
      {
        "measBandwidth": 10000000,
        "measFrequency": 3550000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3560000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3570000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3580000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3590000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3600000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3610000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3620000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3630000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3640000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3650000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3660000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3670000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3680000000,
        "measRcvdPower": -79
      },
      {
        "measBandwidth": 10000000,
        "measFrequency": 3690000000,
        "measRcvdPower": -79
      }
    ]
  },
  "registrationRequest": {
    "airInterface": {
      "radioTechnology": "E_UTRA"
    },
    "bbuSerialNumber": "GH1234567890",
    "callSign": "123",
    "cbsdCategory": "B",
    "cbsdInfo": {
      "firmwareVersion": "86",
      "hardwareVersion": "R3006-G0001",
      "model": "ENB-5186A,II1,H04FH1PT1LS7A22I",
      "softwareVersion": "EENB51_A0AAUBBUV01.01.01.01_20.05_SAS_01.05",
      "vendor": "SYNAXG"
    },
    "cbsdSerialNumber": ["GH1234567890:ER003A-2531051074", "GH1234567890:ER003A-2531051077"],
    "fccId": "synatest25",
    "groupingParam": [
      {
        "groupId": "1",
        "groupType": "INTERFERENCE_COORDINATION"
      }
    ],
    "installationParam": {
      "antennaAzimuth": 240,
      "antennaBeamwidth": 0,
      "antennaDowntilt": 0,
      "antennaGain": 6,
      "antennaModel": "",
      "eirpCapability": 47,
      "height": 11.8,
      "heightType": "AMSL",
      "horizontalAccuracy": 10,
      "indoorDeployment": false,
      "latitude":37.373565,
      "longitude":-121.960298,
      "verticalAccuracy": 1
    },
    "measCapability": ["RECEIVED_POWER_WITH_GRANT"],
    "userId": "synaxg-dp25",
    "userName": "sg-user",
    "userPassword": "123456"
  }
}')

echo "Response from SAS DP:"
echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
