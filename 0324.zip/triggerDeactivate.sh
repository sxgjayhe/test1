#!/usr/bin/bash

curl -X POST http://127.0.0.1:5000/api/BBU/deactivateRequest \
  -H "Content-Type: application/json;charset=utf-8" \
  -d '{
    "deactivateRequest": {
      "rruSerialNumber": "ER003A-2531051074",
      "adminState":"false",
      "errorCode":"106"
    }
  }'

  sleep 2

curl -X POST http://127.0.0.1:5000/api/BBU/deactivateRequest \
  -H "Content-Type: application/json;charset=utf-8" \
  -d '{
    "deactivateRequest": {
      "rruSerialNumber": "ER003A-2531051077",
      "adminState":"false",
      "errorCode":"106"
    }
  }'
