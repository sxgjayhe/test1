#!/bin/bash

URL="http://127.0.0.1:8000/api/DP/relinquishmentRequest"

response=$(curl -s -X POST "$URL" \
     -H "Content-Type: application/json;charset=UTF-8" \
     -H "Accept: application/json" \
     -H "device-url-info: http://127.0.0.1:5000" \
     -d '{
    "bbuSerialNumber": "GH1234567890"
}')

echo "Response from SAS DP:"
echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
