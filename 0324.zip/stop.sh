#!/bin/bash

#jps -v|grep appName=domain-proxy| awk '{print $1}'|xargs -r kill -9
killall java
