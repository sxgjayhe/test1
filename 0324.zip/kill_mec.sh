#!/usr/bin/bash


ps -ef | grep  MecProxy | grep -v grep | awk '{print $2}' | xargs kill
